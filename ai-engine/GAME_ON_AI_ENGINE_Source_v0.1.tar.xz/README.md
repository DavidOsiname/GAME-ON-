# GAME ON AI ENGINE — foundation

A cloud-first AI-assisted game-production workspace. This first milestone delivers the project setup, GDD ingestion, and development-plan workflow. It is a foundation, not yet a finished game generator or console build system.

## Current milestone

- Create a game project and choose target platforms.
- Provide a prompt of at least 40 characters, with or without a GDD.
- Choose guided or automatic planning mode.
- Start with a written game prompt or upload a PDF, DOCX, Markdown, or plain-text GDD.
- Extract and store the document text locally.
- Generate a structured development plan using an OpenAI-compatible chat-completions endpoint when credentials are configured.
- Without a model key, return a clearly labelled rule-based preview instead of pretending it is AI-generated.

## Repository layout

```text
ai-engine/
  apps/
    api/       FastAPI service, SQLite persistence, GDD extraction, AI planner
    web/       Next.js dashboard
  ARCHITECTURE.md
  .env.example
```

## Requirements

- Python 3.11+
- Node.js 20.9+
- npm

## Run the API

```bash
cd apps/api
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -e ".[dev]"
uvicorn engine_api.main:app --reload --port 8000
```

## Run the dashboard

In another terminal:

```bash
cd apps/web
npm install
npm run dev
```

Open http://localhost:3000. The API runs at http://localhost:8000.

## Configure AI planning

Copy `.env.example` to `apps/api/.env` and set `OPENAI_API_KEY`. The API loads that file automatically. The default model is configurable with `OPENAI_MODEL`; `OPENAI_BASE_URL` supports compatible providers. Never commit real keys. Without a key, the application uses a labelled preview planner.

The dashboard uses `NEXT_PUBLIC_API_URL`, defaulting to `http://localhost:8000`.

## Important platform limits

The platform selector records the intended targets; it does not currently produce platform builds. Android, iOS, PC, PlayStation, and Xbox each need platform-specific toolchains, signing, SDKs, developer approvals, and testing. Console packaging will require authorized Sony/Microsoft developer access. iOS packaging requires macOS/Xcode and Apple signing. Those adapters are later milestones.

## Safety and quality gates

The plan generator treats uploaded GDD content as untrusted project data, not executable instructions. No uploaded code is executed. AI output is a proposed plan and must be reviewed. Future generation stages will require artifact validation, automated tests, human approval in guided mode, and explicit release checks.
