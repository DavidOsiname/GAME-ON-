from __future__ import annotations

import json
import os
import sqlite3
from pathlib import Path
from typing import Any
from uuid import uuid4
from datetime import datetime, timezone


def _db_path() -> Path:
    path = Path(os.getenv("DATABASE_PATH", "./data/engine.db"))
    if not path.is_absolute():
        path = Path(__file__).resolve().parents[1] / path
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _connect() -> sqlite3.Connection:
    connection = sqlite3.connect(_db_path())
    connection.row_factory = sqlite3.Row
    return connection


def init_db() -> None:
    with _connect() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS projects (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT NOT NULL,
            platforms_json TEXT NOT NULL,
            generation_mode TEXT NOT NULL,
            quality_target TEXT NOT NULL,
            gdd_filename TEXT,
            gdd_text TEXT,
            created_at TEXT NOT NULL
        )""")


def _serialize(row: sqlite3.Row) -> dict[str, Any]:
    return {
        "id": row["id"],
        "name": row["name"],
        "description": row["description"],
        "platforms": json.loads(row["platforms_json"]),
        "generation_mode": row["generation_mode"],
        "quality_target": row["quality_target"],
        "gdd_filename": row["gdd_filename"],
        "gdd_status": "uploaded" if row["gdd_filename"] else "missing",
        "created_at": row["created_at"],
    }


def create_project(payload: dict[str, Any]) -> dict[str, Any]:
    project_id = str(uuid4())
    created_at = datetime.now(timezone.utc).isoformat()
    with _connect() as con:
        con.execute(
            "INSERT INTO projects (id,name,description,platforms_json,generation_mode,quality_target,created_at) VALUES (?,?,?,?,?,?,?)",
            (project_id, payload["name"], payload.get("description", ""), json.dumps(payload["platforms"]), payload["generation_mode"], payload["quality_target"], created_at),
        )
        row = con.execute("SELECT * FROM projects WHERE id = ?", (project_id,)).fetchone()
    return _serialize(row)


def list_projects() -> list[dict[str, Any]]:
    with _connect() as con:
        rows = con.execute("SELECT * FROM projects ORDER BY created_at DESC").fetchall()
    return [_serialize(row) for row in rows]


def get_project(project_id: str) -> dict[str, Any] | None:
    with _connect() as con:
        row = con.execute("SELECT * FROM projects WHERE id = ?", (project_id,)).fetchone()
    return _serialize(row) if row else None


def get_project_with_input(project_id: str) -> tuple[dict[str, Any], str, str] | None:
    with _connect() as con:
        row = con.execute("SELECT * FROM projects WHERE id = ?", (project_id,)).fetchone()
    if not row:
        return None
    if row["gdd_text"]:
        return _serialize(row), row["gdd_text"], "gdd"
    return _serialize(row), row["description"] or "", "prompt"


def save_gdd(project_id: str, filename: str, extracted_text: str) -> dict[str, Any] | None:
    with _connect() as con:
        con.execute("UPDATE projects SET gdd_filename = ?, gdd_text = ? WHERE id = ?", (filename, extracted_text, project_id))
        row = con.execute("SELECT * FROM projects WHERE id = ?", (project_id,)).fetchone()
    return _serialize(row) if row else None
