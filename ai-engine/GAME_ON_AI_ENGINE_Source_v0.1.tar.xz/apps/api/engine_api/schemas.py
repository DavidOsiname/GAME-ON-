from __future__ import annotations

from typing import Literal
from pydantic import BaseModel, Field, field_validator

PLATFORMS = {"android", "ios", "windows", "macos", "playstation", "xbox"}


class ProjectCreate(BaseModel):
    name: str = Field(min_length=2, max_length=80)
    description: str = Field(default="", max_length=2000)
    platforms: list[str] = Field(min_length=1)
    generation_mode: Literal["guided", "automatic"] = "guided"
    quality_target: Literal["maximum"] = "maximum"

    @field_validator("platforms")
    @classmethod
    def validate_platforms(cls, values: list[str]) -> list[str]:
        normalized = list(dict.fromkeys(value.strip().lower() for value in values))
        unknown = sorted(set(normalized) - PLATFORMS)
        if unknown:
            raise ValueError(f"Unsupported platform(s): {', '.join(unknown)}")
        if not normalized:
            raise ValueError("Choose at least one target platform")
        return normalized


class ProjectOut(BaseModel):
    id: str
    name: str
    description: str
    platforms: list[str]
    generation_mode: str
    quality_target: str
    gdd_filename: str | None = None
    gdd_status: str = "missing"
    created_at: str


class PlanStage(BaseModel):
    id: str
    title: str
    description: str
    deliverables: list[str]
    acceptance_criteria: list[str]
    estimated_complexity: Literal["small", "medium", "large"]


class DevelopmentPlan(BaseModel):
    project_id: str
    input_source: Literal["gdd", "prompt"]
    provider: str
    is_ai_generated: bool
    summary: str
    assumptions: list[str]
    stages: list[PlanStage]
    risks: list[str]
    review_required: bool = True
    notice: str | None = None
