from fastapi.testclient import TestClient
from engine_api.main import app


def create_test_project(client, description="A third-person fantasy adventure about a lost explorer."):
    response = client.post("/api/projects", json={
        "name": "Test project",
        "description": description,
        "platforms": ["android", "windows"],
        "generation_mode": "guided",
        "quality_target": "maximum",
    })
    return response


def test_health():
    with TestClient(app) as client:
        response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_create_project_validates_platforms():
    with TestClient(app) as client:
        response = create_test_project(client)
    assert response.status_code == 201
    body = response.json()
    assert body["platforms"] == ["android", "windows"]
    assert body["gdd_status"] == "missing"


def test_reject_unknown_platform():
    with TestClient(app) as client:
        response = client.post("/api/projects", json={
            "name": "Test project",
            "platforms": ["toaster"],
            "generation_mode": "guided",
            "quality_target": "maximum",
        })
    assert response.status_code == 422


def test_prompt_only_project_can_generate_preview_plan(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    with TestClient(app) as client:
        created = create_test_project(client)
        project_id = created.json()["id"]
        response = client.post(f"/api/projects/{project_id}/plan")
    assert response.status_code == 200
    plan = response.json()
    assert plan["input_source"] == "prompt"
    assert plan["is_ai_generated"] is False
    assert len(plan["stages"]) >= 5


def test_gdd_upload_then_plan(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    with TestClient(app) as client:
        created = create_test_project(client, description="")
        project_id = created.json()["id"]
        upload = client.post(
            f"/api/projects/{project_id}/gdd",
            files={"file": ("design.md", b"# A fantasy game\n\nA third-person adventure with exploration, crafting, quests, and cooperative combat. The hero discovers an ancient world.", "text/markdown")},
        )
        response = client.post(f"/api/projects/{project_id}/plan")
    assert upload.status_code == 200
    assert upload.json()["gdd_status"] == "uploaded"
    assert response.status_code == 200
    assert response.json()["input_source"] == "gdd"
